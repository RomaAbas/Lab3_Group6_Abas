
public class Queue <T>{
	
	T [] container;
	int front, back;
	
	Queue(int capacity){
		container = (T[])new Object[capacity];
		front = -1;
		back = -1;
	}
	
	void clear() {
		front = -1;
		back = -1;
	}
	
	boolean isEmpty() {
		if(front==-1 && back==-1) return true;
		return false;
	}
	
	boolean isFull() {
		if(front == container.length-1) return true;
		return false;
	}
	
	void enqueue(T item) {
		
		
		if(isEmpty()) {
			front=0; back=0;
			container[0] = item;
		
		
		}else if(isFull()) {
			System.out.println("Queue is full...");
		}else {
			back++;
			container[back] = item;
		}
		
	}
	
	T dequeue() {
		if(isEmpty()) {
			return null;
		}else {
			T temp = container[front];
			front++;
			return temp;
		}
	}
	
	T peek() {
		if(isEmpty()) {
			return null;
		}else {
			return container[front];
		}
	}
}
