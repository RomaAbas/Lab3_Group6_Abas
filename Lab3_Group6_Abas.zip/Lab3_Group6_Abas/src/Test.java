import java.util.*;
  
class Test{  
public static void main(String args[]){  
	Queue<Vehicle> q  = new Queue (20);
	
	Vehicle v1 = new Vehicle("Toyota", "Red", "Automatic");
	Vehicle v2 = new Vehicle("Mitsubishi", "White", "Automatic");
	Vehicle v3 = new Vehicle("Honda", "Black", "Manual");
	
	q.enqueue(v1);
	q.enqueue(v2);
	q.enqueue(v3);
	
	System.out.println(q.isEmpty());
	
	System.out.println(q.isFull());
	
	q.dequeue();
	
	System.out.println(q.peek().brand + " " + q.peek().color + " " + q.peek().transmission);
	
}  
}  