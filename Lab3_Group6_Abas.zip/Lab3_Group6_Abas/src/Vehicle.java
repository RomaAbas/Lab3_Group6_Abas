
public class Vehicle {
	String brand;
	String color;
	String transmission;
	
	Vehicle (String brand, String color, String transmission) {
		this.brand = brand;
		this.color=color;
		this.transmission=transmission;
	}
}
